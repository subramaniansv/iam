package com.iam.app.mapper;

import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.iam.app.models.*;
public class PermissionConverterUtil {
    public static Permission requestToDto(HttpServletRequest request) {
    try {
        ObjectMapper mapper = new ObjectMapper();
          mapper.registerModule(new JavaTimeModule());
        return mapper.readValue(request.getInputStream(), Permission.class);
    } catch (Exception e) {
        throw new RuntimeException("Failed to parse request JSON", e);
    }
}
}
