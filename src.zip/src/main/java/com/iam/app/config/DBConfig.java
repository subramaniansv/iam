package com.iam.app.config;


import java.sql.Connection;
import java.sql.DriverManager;
public class DBConfig {
 private static final String URL =
        "jdbc:mysql://127.0.0.1:3306/iam";

    private static final String USERNAME = "root";
    private static final String PASSWORD = "Root@123";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            throw new RuntimeException("Mysql connection failed", e);
        }
    }
}